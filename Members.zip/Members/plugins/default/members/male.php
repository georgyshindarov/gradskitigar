<?php

$users = new OssnUser;
$users = $users->searchUsers(array(
                'page_limit' => false,
                'entities_pairs' => array(
                    'key_1' => array ('name' => 'gender', 'value' => 'male')
                )
    ));
	
$list       = ossn_plugin_view('output/users', array(
		'users' => $users
));

$html  = <<<EOD
 <div	
     $list  
</div>
EOD;
echo $html;