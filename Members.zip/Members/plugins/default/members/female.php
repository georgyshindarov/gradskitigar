<?php

$users = new OssnUser;
$params_to_export = array("first_name", "last_name", "email"); //for email just keep email and remove others.
$users = $users->searchUsers(array(
                'page_limit' => false,
                'entities_pairs' => array(
                    'key_1' => array ('name' => 'gender', 'value' => 'female')
                )
    ));



$list       = ossn_plugin_view('output/users', array(
		'users' => $users
));






$html  = <<<EOD
 <div	
     $list  
</div>
EOD;
echo $html;